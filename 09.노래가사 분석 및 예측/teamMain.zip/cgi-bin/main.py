from flask import Flask, request, redirect, render_template, url_for
import os
app = Flask(__name__)

template_dir = os.path.join(os.path.dirname(__file__),'templates')

"""
# URL : http://127.0.0.1:8080/
"""
# 모듈 로딩 ---------------------------------------------------
import cgi, sys, codecs, os
from pydoc import html
import joblib
from konlpy.tag import Okt
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer


# WEB 인코딩 설정 ---------------------------------------------
# sys.stdout=codecs.getwriter('utf-8')(sys.stdout.detach())
# 판정 --------------------------------------------------------
# # 데이터 정제
def trans_data(text):

    df = pd.read_csv(os.path.dirname(__file__)+ '/make_model/data/data.csv')

    # 벡터화
    cv = CountVectorizer()
    dtm = cv.fit_transform(df['data'])

    okt = Okt()
    words = []

    for w,t in okt.pos(text):
        if t in ['Noun','Verb','Adjective', 'Alpha']:
            words.append(w)
        elif (t == 'Punctuation') and ('*' in w):
            words.append(w)
        
    sent = pd.DataFrame([' '.join(words)])
    dtm = cv.transform(sent.iloc[0])
    data = pd.DataFrame(dtm.toarray(), columns=cv.get_feature_names_out())

    return data

# 장르, 긍정 분류
def genre_predict(text):
    result = genre_model.predict(trans_data(text))
    return result[0]

def pn_predict(text):
    result = pn_model.predict(trans_data(text))
    if result[0] == 0:
        return '부정'
    elif result[0] == 1:
        return '긍정'


# 기능 구현 -----------------------------------------------------
# (1) 장르 분류 모델 호출
genre_pklfile = os.path.dirname(__file__) + "/make_model/pycaret_model.pkl"
genre_model = joblib.load(genre_pklfile)

# (2) 감성 분류 모델 호출
pn_pklfile = os.path.dirname(__file__) + "/make_model/pn_model.pkl"
pn_model = joblib.load(pn_pklfile)


# 기능 구현 -----------------------------------------------------
# 웹에서 텍스트 업로드
from flask import Flask, request, redirect, render_template, url_for
import os
app = Flask(__name__)

# main 페이지
@app.route('/')
def index():
    return render_template('main.html')

# 텍스트 데이터 받아 결과 페이지에 넘김, 결과 페이지 오픈
@app.route("/upload_done", methods=["GET"])
def upload_done():

    _id = int(request.args.get("id"))
    _lyric = request.args.get("lyric")

    if _id == 0:
        result1 = genre_predict(_lyric)
        return open("./cgi-bin/templates/result1.html", mode='r', encoding='UTF-8').read().replace("<result1>", result1)

    elif _id == 1:
        result2 = pn_predict(_lyric)
        return open("./cgi-bin/templates/result2.html", mode='r', encoding='UTF-8').read().replace("<result2>", result2)
    

app.run(host='127.0.0.1', port=8080)